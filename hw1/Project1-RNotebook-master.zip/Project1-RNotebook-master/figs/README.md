# ADS Project 1:  R Notebook on the Presidential Elections in the US

### Figs folder

The figs directory contains the figures. This directory only contains generated files; that is, one should always be able to delete the contents and regenerate them.
