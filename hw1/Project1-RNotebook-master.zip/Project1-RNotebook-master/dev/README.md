# ADS Project 1:  R Notebook on the Presidential Elections in the US

### Code dev/lib Folder

The lib directory contains various files with function definitions and computation codes for your data analysis. 

