# ADS Project 1:  R Notebook on the Presidential Elections in the US

### Output folder

The output directory contains analysis output, processed datasets, logs, or other processed things.

