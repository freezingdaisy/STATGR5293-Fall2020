# ADS Project 1:  R Notebook on the Presidential Elections in the US

### Doc folder

The doc directory contains the report or presentation files. It can have subfolders.  
